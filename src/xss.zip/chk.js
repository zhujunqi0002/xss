window.alert = function()
 {
    confirm("完成的不错！");
}
